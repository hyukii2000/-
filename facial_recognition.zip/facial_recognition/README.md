# Raspberry Pi 4 Facial Recognition
Full Tutorial posted - https://www.tomshardware.com/how-to/raspberry-pi-facial-recognition

![RaspberryPi Facial Rec](https://github.com/carolinedunn/facial_recognition/blob/main/photo/screenshot.png)

Materials: Raspberry Pi 4 and Webcam

![RaspberryPi Facial Rec](https://github.com/carolinedunn/facial_recognition/blob/main/photo/webcamandRPi4.JPG)

Full Tutorial posted - https://www.tomshardware.com/how-to/raspberry-pi-facial-recognition
